<?php include '../core/init.php'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include("../includes/adminhead2.php"); ?>
<div class="page-wrapper">
	        <div class="row" style="color:white;"><br>
	            <div class="col-lg-12">
	                <h1 class="page-header">ADD PRODUCT</h1>
	            </div>
	        </div>
	        <div class="row">
	        	<div class="col-lg-12">
	        		<div class="col-lg-12">
	        	<div class="panel panel-default">
	        		<div class="panel-body">
                <div class="col-lg-11 col-xs-offset-3">
                    <form class="form-horizontal" role="form" method="post" action="create_product.php">
                    
                    <h3>Product Information:</h3><br>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="Mobile" >Name:</label>
                        <div class="col-sm-3">
                            <input type="text" onkeypress="letternumber(event)" class="form-control" name="Name" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="Mobile" >Product Picture:</label>
                        <div class="col-sm-3">
                            <?php
                               print "<input type='file' class='form' name='ProductPict' required>";
                            ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="Mobile" >Stocks:</label>
                        <div class="col-sm-3">
                            <input type="text" onkeypress="numonly(event)" maxlength="4" class="form-control" name="Stocks" aria-describedby="basic-addon1" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="Mobile" >Price:</label>
                        <div class="col-sm-3">
                            <input type="text" onkeypress="numonly(event)" maxlength="6" class="form-control" name="Price" aria-describedby="basic-addon1" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="Mobile" >Description:</label>
                        <div class="col-sm-3">
                            <textarea class="form-control" onkeypress="letternumber(event)" name="Description" aria-describedby="basic-addon1" required></textarea>
                        </div>
                    </div>
                     <br>
                    <button class="btn btn-success col-xs-offset-2" name="submit">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <a href="manage.php" class="btn btn-success" role="button">Back</a>    
                 </div>
             </div>
         </div>
     </div>
     </div>
            </div>
		</div>
</body>
</html>