<?php include '../core/init.php'; ?>
<?php
    if(isset($_POST["submit"]))
    {   
            $name = sanitize($_POST["Name"]);
            $productPict = sanitize($_POST["ProductPict"]);
            $stocks = sanitize($_POST["Stocks"]);
            $description = sanitize($_POST["Description"]);
            $price = sanitize($_POST["Price"]);

            $query = "INSERT INTO products (";
            $query .= " name, product_picture, stocks, price, description";
            $query .= ") VALUES (";
            $query .= " '{$name}', '{$productPict}', '{$stocks}', '{$price}', '{$description}')";

            $result = mysql_query($query);

            if($result)
            {
                $_SESSION["success_message"] = "Successfully Added.";
                header("Location: manage.php");
            }
            else
            {
                $_SESSION["error_message"] = "Failed to add.";
                header("Location: manage.php");
            }
        
    }
?>