<?php include '../core/init.php'; ?>
<?php
    $product_id = sanitize($_GET["ProductId"]);

    if((!isset($_GET["ProductId"]) || empty($product_id)))
    {
        header("Location: manage.php");
    }
?>
<?php
    $get_rent_info = "SELECT * from products where product_id = '{$product_id}'";
    $get_info = mysql_query($get_rent_info);
    $rent = mysql_fetch_assoc($get_info);

    $product_id = $rent["product_id"];

    if(!$product_id){
        header("Location: manage.php");
    }

    //Update Status
    $query="DELETE from products WHERE product_id='{$product_id}'";
    $result_order = mysql_query($query);

    if($result_order)
    {
        $_SESSION["success_message"] = "Product number: {$product_id} has been deleted.";
        header("Location: manage.php");
    } 
    else 
    {
        $_SESSION["error_message"] = "Product number: {$product_id} delete failed.";
        header("Location: manage.php");

    }
?>