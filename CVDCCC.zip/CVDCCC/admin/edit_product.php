<?php include '../core/init.php'; ?>
<?php
    $product_id = sanitize($_GET["ProductId"]);

    if((!isset($_GET["ProductId"]) || empty($product_id)))
    {
        header("Location: manage.php");
    }
?>
<?php
    $querys = "SELECT * FROM products where product_id = '{$product_id}'";
    $results = mysql_query($querys);
   
?>

<?php
    if(isset($_POST["submit"]))
    {   
            $name = sanitize($_POST["Name"]);
            $productPict = sanitize($_POST["ProductPict"]);
            $stocks = sanitize($_POST["Stocks"]);
            $description = sanitize($_POST["Description"]);
            $price = sanitize($_POST["Price"]);

            $query = "UPDATE products SET ";
            $query .= "name ='{$name}', product_picture='{$productPict}', stocks='{$stocks}', price='{$price}', description='{$description}'";
            $query .= "WHERE product_id='{$product_id}'";

            $result = mysql_query($query);

            if($result)
            {
                $_SESSION["success_message"] = "Product number: " . $product_id . " has been updated.";
                header("Location: manage.php");
            }
            else
            {
                $_SESSION["error_message"] = "Update Failed.";
                header("Location: manage.php");
            }
        
    }
?>
<?php include("../includes/adminhead2.php"); ?>
        <div class="page-wrapper">
            <div class="row" style="color:white;"><br>
                <div class="col-lg-12">
                <h1 class="page-header">EDIT PRODUCT</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-body">
                                <div class="col-lg-11 col-xs-offset-3">
                                    <form class="form-horizontal" role="form" method="post" action="edit_product.php?ProductId=<?php echo $product_id; ?>">

                                        <h3>Product Information:</h3><br>
                                        <?php
                                            $row = mysql_fetch_assoc($results);
                                        ?>
                                        <img src="<?php echo $row["product_picture"]; ?>" height="200px" width="200px"><br><br>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="Mobile" >Name:</label>
                                            <div class="col-sm-3">
                                                <input type="text" onkeypress="letternumber(event)" class="form-control" value="<?php echo $row["name"]; ?>" name="Name" required>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="Mobile" >Product Picture:</label>
                                            <div class="col-sm-3">
                                            <?php
                                                print "<input type='file' class='form' name='ProductPict' required>";
                                            ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="Mobile" >Stocks:</label>
                                            <div class="col-sm-3">
                                                <input type="text" onkeypress="numonly(event)" maxlength="4" class="form-control" name="Stocks" value="<?php echo $row["stocks"]; ?>" aria-describedby="basic-addon1" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="Mobile" >Price:</label>
                                            <div class="col-sm-3">
                                                <input type="text" onkeypress="numonly(event)" maxlength="6" class="form-control" name="Price" value="<?php echo $row["price"]; ?>" aria-describedby="basic-addon1" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-2" for="Mobile" >Description:</label>
                                            <div class="col-sm-3">
                                                <textarea class="form-control" onkeypress="letternumber(event)" name="Description" aria-describedby="basic-addon1" required><?php echo $row["description"]; ?></textarea>
                                            </div>
                                        </div>
                                        <br>
                                    <button class="btn btn-success col-xs-offset-2" type="submit" name="submit">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="manage.php" class="btn btn-success" role="button">Back</a>    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>