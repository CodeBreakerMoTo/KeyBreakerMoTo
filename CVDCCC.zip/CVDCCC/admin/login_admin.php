
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grab-a-Shirt Admin Login</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

     <script src="../js/bootstrap.min.js"></script>

  </head>
<script type="text/javascript">
function numonly(evt) 
	{
		var theEvent = evt || window.event;
		var key = theEvent.keyCode || theEvent.which;
		key = String.fromCharCode( key );
		var regex = /[0-9 \b]|\./;
		if( !regex.test(key) ) 
		{
			theEvent.returnValue = false;
			if(theEvent.preventDefault) theEvent.preventDefault();
		}
	}

function letternumber(evt) 
{ 
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode( key );
	var regex = /[a-z A-Z0-9_\b]|\ /;
	if( !regex.test(key) ) 
	{
		theEvent.returnValue = false;
		if(theEvent.preventDefault) theEvent.preventDefault();
	}
}

function charonly(evt) 
{
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode( key );
	var regex = /[a-z A-Z\b]|\./;
	if( !regex.test(key) ) 
	{
		theEvent.returnValue = false;
		if(theEvent.preventDefault) theEvent.preventDefault();
	}
}
</script>
<?php
	include '../core/init.php';
	
	if (empty($_POST) === false)
	{
		$username = $_POST	['txtbUser'];
		$password = $_POST ['txtbPassword'];
		
		if (empty($username) === true || empty($password) === true)
		{
			$errors[] = 'You need to enter a registered email and password.';
		}
		else if (admin_exists($username) === false)
		{
			$errors[] = 'We can\'t find that email. Have you registered?';
		}
		else
		{
			$login = login_admin($username, $password);
			if ($login === false)
			{
				$errors[] = 'The password you entered is incorrect!';
			}
			else
			{
				$_SESSION['admin_id'] = $login;
				header('Location: usersview.php');
				exit();
			}
		}
		
	}
	
?>

	
	<body background="../images/bg2.jpg">
    <div class="container">
		<p></br></p>
		<div class="row"><br><br><br>
			<div class="col-md-4">
			</div>
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h3>Welcome Admin!</h3>
							<?php
								if (empty($errors) === false)
								{
									echo output_errors($errors);
								}
							?>
						</div>
						<form action="login_admin.php" method="post">
							<div class="form-group">
    								<label for="txtbUser">Username</label>
    							<div class="form-group">
  									
  									<input type="text" class="form-control" onkeypress="letternumber(event)" id="txtbUser" name="txtbUser" maxlength="80" placeholder="Username">
								</div>
  							</div>
							<div class="form-group">
    								<label for="txtbPassword">Password</label>
    							<div class="form-group">
  									
  									<input type="password" class="form-control" id="txtbPassword"maxlength="32" name="txtbPassword" placeholder="Password">
								</div>
  							</div>
							<hr>
							<p></p>
							<button type="submit" class="btn btn-default"> Login</button>
							<button type="reset" class="btn btn-default"> Reset</button>
							
						</form>
					</div>
				</div>
		</div>
	</div>

  
  </body>
	
</html>