<?php include '../core/init.php'; ?>
<?php
	unset($_SESSION["admin_id"]);
	header("Location: login_admin.php");
?>