<?php include '../core/init.php'; ?>
<?php
	$query = "SELECT * from products";
	$result = mysql_query($query);
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../includes/adminhead2.php'; ?>
<div class="page-wrapper">
	        <div class="row" style="color:white"><br>
	            <div class="col-lg-12">
	                <h1 class="page-header">Manage Products</h1>
	            </div>
	            <!-- /.col-lg-12 -->
	        </div><div class="col-lg-12">
	        <div class="panel panel-default">
	        	<div class="panel-body">
	        		

	        <div class="col-lg-12">
	        	<?php echo success_message(); ?>
                    <?php echo error_message(); ?>
	        	<a href="add_product.php">+Add New Product</a><br><br>
	        	<div class="table-responsive">
                    <table id="historyTable" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th><center>Product ID</center></th>
                                <th><center>Name</center></th>
                                <th><center>Product Picture</center></th>
                                <th><center>Stocks</center></th>
                                <th><center>Price</center></th>
                                <th><center>Description</center></th>
                                <th></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody style="font-family: courier new;">
                        	<?php
	                            while($row = mysql_fetch_assoc($result))
	                            {	
	                            	$product_id = $row["product_id"];
	                               //Table Rows
	                                echo "<tr class=alert alert-default>
	                                        <td><br><center><b> " . $row["product_id"] . "</b></center><br></td>
	                                        <td><br><center><b>" . $row["name"] . "</b><br></center></td>
	                                        <td><center><b><img src='" . $row["product_picture"] . "' height='200px' width='200px' ></b><br></center></td>
	                                        <td><br><center><b>" . $row["stocks"] . "</b></center></td>
	                                        <td><br><center>" . $row["price"] . "</center></td>
	                                        <td><br><center>" . $row["description"] . "</center></td>
	                                		<td><br><center><a href=edit_product.php?ProductId={$product_id}>Edit</a></td>
	                                		<td><br><center><a href=delete_product.php?ProductId={$product_id} onclick=\"return confirm('Are you sure you want to delete this product?')\">Delete</a></td>
	                                     </tr>";

	                            }
                            ?>
                        </tbody>
                    </table>
				</div>
			</div>
		</div>
		</div>
	</div>
		</div>
		<script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
		<script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>
		<script>
		            $(document).ready(function() {
		        $('#historyTable').DataTable();
		        responsive: true
		    } );
		</script>
</html>
