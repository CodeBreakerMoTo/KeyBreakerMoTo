<?php include '../core/init.php'; ?>
<?php
	$query = "SELECT sum(quantity), sum(amount) from checkout A ";
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);

	$query2 = "SELECT name, sum(stocks) from products";
	$result2 = mysql_query($query2);
	$row2 = mysql_fetch_assoc($result2);
?>
<div class="col-md-7" >
	        		<h2>Sales Report:</h2>
	        		<h3>Total Net Worth: <b>&#8369;<?php echo $row["sum(amount)"]; ?></b><br></h3>
	        		<h3>Shirts Sold: <b><?php echo $row["sum(quantity)"] ?></b><br></h3>
	        		<ul>
	        		<?php
	        			$x = "SELECT A.check_id, A.datecreated, A.quantity, B.name from checkout A inner join products B on A.product_id = B.product_id ORDER BY A.check_id Asc";
	        			$y = mysql_query($x);
	        			while($z = mysql_fetch_assoc($y))
	        			{
	        				echo "<li>" . $z["name"] . " -------> " . $z["quantity"] . " pc(s) sold Date and Time: " . $z["datecreated"] . "</li><br>";
	        			}
	        		?>
	        	</ul>
	        	</div>
	        	<div class="col-md-4">
	        		<h2>Inventory Report:</h2>
	        		<h3>Stocks Left: <b><?php echo $row2["sum(stocks)"]; ?></b></h3>
	        		<ul>
	        		<?php
	        			$a = "SELECT * from products";
	        			$b = mysql_query($a);
	        			while($c = mysql_fetch_assoc($b))
	        			{
	        				echo "<li>" . $c["name"] . " -------> " . $c["stocks"] .  " pc(s) left</li><br>";
	        			}
	        		?>
	        	</ul>
	        	</div>
	        <div class="col-lg-12">
	        	
			</div>