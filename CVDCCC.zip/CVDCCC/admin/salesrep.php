<?php include '../core/init.php'; ?>
<?php
	$query = "SELECT sum(quantity), sum(amount) from checkout A ";
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);

	$query2 = "SELECT name, sum(stocks) from products";
	$result2 = mysql_query($query2);
	$row2 = mysql_fetch_assoc($result2);
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../includes/adminhead3.php'; ?>
<div class="page-wrapper">
	        <div class="row" style="color:white"><br>
	            <div class="col-lg-12">
	                <h1 class="page-header">Transaction Report</h1>
	            </div>
	            <!-- /.col-lg-12 -->
	        </div><div class="col-lg-12">
	        <div class="panel panel-default">
	        	<div class="panel-body">
	        		<div id="report">
	        		
		</div>
		</div>
		</div>
	</div>
		</div>
</html>
