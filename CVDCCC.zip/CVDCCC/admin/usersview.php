<?php include '../core/init.php'; ?>
<!DOCTYPE html>
<html lang="en">
<?php include("../includes/adminhead.php"); ?>

<div class="row"><br><br><br>
	<div class="col-md-1"></div>
		<div class="col-md-10">
			<div class="panel panel-default">
				<div class="panel-body">
					<div class="page-header">
						<h3>Users</h3>
					</div>
				<div class="table-responsive">
				<table id="historyTable" class="table table-striped table-bordered">
					<thead>
						<tr>
							<th><b><center>User ID</center></b>
							<th><b><center>First Name</center></b>
							<th><b><center>Last Name</center></b>
							<th><b><center>Gender</center></b>
							<th><b><center>Email</center></b>
							<th><b><center>Address</center></b>
							<th><b><center>Contact Number</center></b>
							<th><b><center>Birthdate</center></b>
						</tr>
					</thead>
					<tbody>
						<?php 
							 
							$query = "Select * from users";
							$result = mysql_query($query);
							$count = mysql_numrows($result);
							if ( $count == 0)
							print "No Record to be Displayed";
							else
							{
								while ($row=mysql_fetch_array($result))
								{
									$a=$row['user_id'];
									$b=$row['first_name'];
									$c=$row['last_name'];
									$d=$row['gender'];	
									$e=$row['email'];
									$f=$row['address'];
									$g=$row['contact_number'];
									$h=$row['birthdate'];
									print "<tr><td>" . $a . "</td>
											<td>" . $b . "</td>
											<td>" . $c . "</td>
											<td>" . $d . "</td>
											<td>" . $e . "</td>
											<td>" . $f . "</td>
											<td>" . $g . "</td>
											<td>" . $h . "</td></tr>";

								}
								print "</tbody>
									</table> Total Record/s <b>$count";
							}

						?>
					
				</div>
			</div>
		</div>
	</div>
	<div class="col-md-1"></div>
</div>

<script>
	$(document).ready(function() {
	$('#historyTable').DataTable();
	responsive: true
	} );
</script>
	
  </body>
</html>