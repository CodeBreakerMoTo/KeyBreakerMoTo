<?php
$connect_error = 'Sorry, We\'re experiencing connection problems.';
$connect_error2 = 'Can\'t locate database.';
mysql_connect('localhost', 'root', '') or die($connect_error);
mysql_select_db('cvdccc') or die($connect_error2);

?>