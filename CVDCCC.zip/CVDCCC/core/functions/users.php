<?php
	function register_user($register_data)
	{
		array_walk($register_data, 'array_sanitize');
		$register_data['password'] = md5 ($register_data['password']);
		
		$fields = '`' . implode('`, `', array_keys($register_data)) . '`';
		$data = '\'' . implode('\', \'',$register_data) . '\'';
		
		mysql_query("INSERT INTO `users` ($fields) VALUES ($data)");
	}

	function logged_in()
	{
		return (isset($_SESSION['user_id'])) ? true : false;
	}
	
	function user_exists($username)
	{
		$username = sanitize($username);
		$query = mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$username'");
		return (mysql_result($query, 0) == 1) ? true : false;
	}
	
	function admin_exists($username)
	{
		$username = sanitize($username);
		$query = mysql_query("SELECT COUNT(`admin_id`) FROM `admin` WHERE `username` = '$username'");
		return (mysql_result($query, 0) == 1) ? true : false;
	}
	
	function user_id_from_username($username)
	{
		$username = sanitize($username);
		return mysql_result(mysql_query("SELECT `user_id` FROM `users` WHERE `email` = '$username'"), 0, 'user_id');
	}
	
	function admin_id_from_username($username)
	{
		$username = sanitize($username);
		return mysql_result(mysql_query("SELECT `admin_id` FROM `admin` WHERE `username` = '$username'"), 0, 'admin_id');
	}
	
	function login($username, $password)
	{
		$user_id = user_id_from_username($username);
		
		$username = sanitize($username);
		$password = md5($password);
		
		return (mysql_result(mysql_query("SELECT COUNT(`user_id`) FROM `users` WHERE `email` = '$username' AND `password` = '$password'"), 0) == 1) ? $user_id : false;
	}
	
	function login_admin($username, $password)
	{
		$admin_id = admin_id_from_username($username);
		
		$username = sanitize($username);
		$password = md5($password);
		
		return (mysql_result(mysql_query("SELECT COUNT(`admin_id`) FROM `admin` WHERE `username` = '$username' AND `password` = '$password'"), 0) == 1) ? $admin_id : false;
	}
?>