<?php
	session_start();
	//error_reporting(0);

	require 'database/connect.php';
	require 'functions/general.php';
	require 'functions/users.php';

	$errors = array();
	$ok = array();
	$success = array();

	function sticky_form_user()
	{

		if (isset($_SESSION["Form_Email"])||isset($_SESSION["Form_Firstname"])
			||isset($_SESSION["Form_Lastname"])||isset($_SESSION["Form_Mobile"])||isset($_SESSION["Form_Address"])
			||isset($_SESSION["Form_Birthmonth"])||isset($_SESSION["Form_Birthday"])||
			isset($_SESSION["Form_Birthyear"])) 
		{
			

			$Email_return=stripslashes($_SESSION["Form_Email"]);
			$Firstname_return=stripslashes($_SESSION["Form_Firstname"]);
			$Lastname_return=stripslashes($_SESSION["Form_Lastname"]);
			$Mobile_return=stripslashes($_SESSION["Form_Mobile"]);
			$Address_return=stripslashes($_SESSION["Form_Address"]);
			$Birth_month = stripslashes($_SESSION["Form_Birthmonth"]);
			$Birth_day = stripslashes($_SESSION["Form_Birthday"]);
			$Birth_year = stripslashes($_SESSION["Form_Birthyear"]);


			$_SESSION["Form_Email"] =NULL ;
			$_SESSION["Form_Firstname"] =NULL ;
			$_SESSION["Form_Lastname"] =NULL;
			$_SESSION["Form_Mobile"] =NULL ;
			$_SESSION["Form_Address"] =NULL ;
			$_SESSION["Form_Birthmonth"] =NULL ;
			$_SESSION["Form_Birthday"]=NULL;
			$_SESSION["Form_Birthyear"]=NULL;
			return array("Email"=>$Email_return,"FirstName"=>$Firstname_return,
				"LastName"=>$Lastname_return,"Mobile"=>$Mobile_return,
				"Address"=>$Address_return,"Birthmonth"=>$Birth_month,"Birthday"=>$Birth_day,"Birthyear"=>$Birth_year,
				);
		}
	
	}

	function error_message()
	{
		if (isset($_SESSION["error_message"]))
		{
			$output = "<div class=\"alert alert-danger\">";
			$output .= htmlentities($_SESSION["error_message"]);
			$output .= "</div>";
			$_SESSION["error_message"] = null;
			return $output;
		}
	}

	function success_message()
	{
		if (isset($_SESSION["success_message"]))
		{
			$output = "<div class=\"alert alert-success\">";
			$output .= htmlentities($_SESSION["success_message"]);
			$output .= "</div>";
			$_SESSION["success_message"] = null;
			return $output;
		}
	}

	function message()
	{
		if (isset($_SESSION["message"]))
		{
			$output = "<div class=\"alert alert-info\">";
			$output .= htmlentities($_SESSION["message"]);
			$output .= "</div>";
			$_SESSION["message"] = null;
			return $output;
		}
	}
?> 