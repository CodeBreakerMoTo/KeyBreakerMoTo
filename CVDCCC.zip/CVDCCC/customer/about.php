<?php 
	include '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Us</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>

   </head>
  
  <body background="../images/bg2.jpg">
  
	<header>
		<div class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="home.php" class="navbar-brand">Grab-a-Shirt</a>
				</div>
				<div class="collpase navbar-collapse" id="navbar">
					<ul class="nav navbar-nav">
						<li><a href="profile.php">Profile</a></li>
						<li class=""><a href="home.php">Home</a></li>
						<li class=""><a href="main.php">Shirts</a></li>
						<li class="active"><a href="about.php">About</a></li>
						<li><a href="contacts.php">Contact</a></li>
						<li><a href="cart.php">Cart</a></li>
					</ul>
					
					<form action="" class="navbar-form navbar-right">
						<a href="logout.php" class="btn btn-danger" role="button"> Log out</a>
					</form>
					
				</div>
			</div>
		</div>
		
	</header>
	
	<div class="col-md-2">
	
	</div>
	
	<div class="col-md-8">
	<div class="panel panel-default">
	<div class="panel-body">
	<td colspan="2"><b style="font-size:20px">Welcome to Grab-a-Shirt</b><br><br>
<b>Who we are:</b><br><br>
<b>Grab-a-Shirt</b> This is my SADNAP finals's Project JOHN CARLO SAN JOSE <br><br>
It is a leading international online fashion clothing and accessory store. Focusing on the very latest in affordable fashion styles, both attire and stunning accessories, we feature thousands of the newest product lines, providing maximum choice and convenience to our discerning clientele. We also aim to provide an extensive range of high quality, trendy fashion clothing together with a professional dedicated service to our valued customers from all over the world.<br><br>
Across thousands of product lines, affordable chic combines with effortless elegance in everything from gorgeous Women's Clothing and many more fantastic items at affordable prices.<br><br>
Our goal is always to provide our customers with stunning, high quality fashion products at down to earth prices. CVDC Clothing offers trending fashion-forward styles, edgy and innovative designs all delivered with a truly class-leading professional service.<br><br>
<b>Top 5 Reasons to shop with us</b><br><br>
<ul>
<li>Huge range of quality fashion items: Extensive selection of the very latest styles for both clothing and accessories.</li><br><br>
<li>All new, always new: Exciting products showcasing innovative styles are sourced and added daily by our experienced buyers on CVDC to give you maximum choice.</li><br><br><br>
<li>We love fashion as much as you: Our fashion-savvy staff know quality when they see it, ensuring that each item is perfect and ready to wear before it is shipped.</li><br><br><br>
<li>Buy more, save more: With a world of styles and thousands of products at your finger tips at great prices, your purse will love you as much as your wardrobe.</li><br><br><br>
<li>Our customers always come first: You always matter to us. Our highly trained CS team is always ready to support you no matter the issue. When you buy from us, the sale is not complete when we ship, it is complete when you are completely satisfied.</li></td><br><br>
</ul>
<tr>
<td height="50" align="center" valign="center" width="8%"><img src="../images/pica.gif" width="127" height="123"></td>
<td align="left"><b>Fashion that's affordably yours</b><br>
As a long established global online store, we leverage an extensive network of professional and carefully screened manufacturers and distributors for our products. This process ensures our customers always obtain high quality fashion at the best possible prices. We are totally committed to working with business customers all over the world. If you are interested in our products, please feel free to contact us at any time. We are confident that you will enjoy all the great products available at affordablecustomer prices.<br><br></span></td></tr>
<tr>
<td height="50" align="center" valign="center" width="8%"><img src="../images/picb.gif" width="127" height="123"></td>
<td align="left" valign="center"><b>Fast Shipping / Professional Packaging</b><br>
With internationally renowned logistics operators, including DHL, UPS and EMS, CVDC ships worldwide to more than 200 countries with thousands of orders dispatched securely on an almost daily basis. For total convenience, we offer a broad range of shipping options to fit the needs of every customer.<br> Professional warehouse personnel will take good care of your orders by making sure they are packed in accordance with our rigorous standards. Your products will be carefully checked and securely packed before shipping out.</span></td>
<td style="VERTICAL-ALIGN: top"><br></td>
<td style="VERTICAL-ALIGN: top"><br></td></tr>
<tr>
<td height="50" align="center" valign="center" width="8%"><img src="../images/picc.gif" width="127" height="123"></td>
<td align="left" valign="center"><b>Best in Class Customer Service</b><br>
CVDC offers a professional, dedicated customer service at every possible stage from pre-sales to after-sales. Our highly trained CS specialists are always ready to help you via the user-friendly ticket system, telephone or real-time live chat. When you buy from us, the sale is not complete when we ship, it is complete when you are completely satisfied. </span></td>
</tr>
	
</div>
</div>
</div>
	<div class="col-md-2"></div>
	
  </body>
</html>