<?php 
	require '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<?php
	$product_id = sanitize($_GET["ProductId"]);

    if((!isset($_GET["ProductId"]) || empty($product_id)))
    {
        header("Location: main.php");
    }
?>

<?php

$query = "SELECT * from products where product_id = '{$product_id}'";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);

?>

<?php

	if(isset($_POST["submit"]))
	{
		$query2 = "SELECT * from products where product_id = '{$product_id}'";
		$result2 = mysql_query($query2);
		$row2 = mysql_fetch_assoc($result2);

		$stocks = $row2["stocks"];
		$product_id = $row2["product_id"];
		$name = $row2["name"];
		$price = $row2["price"];

		$quantity = $_POST["quantity"];
		date_default_timezone_set('Asia/Manila');
    	$date_created = date('Y-m-d G:i:s');

    	$stocks_left = $stocks - $quantity;
    	$amount = $price * $quantity;

		if($stocks_left < 0)
		{
			$_SESSION["error_message"] = $name . " has insufficient Stock(s).";
		}
		else
		{	
			$a = "SELECT * from transaction where user_id = '{$id}' and product_id = '{$product_id}'";
			$b = mysql_query($a);
			$num = mysql_num_rows($b);

			if($num > 0)
			{
				$c = mysql_fetch_assoc($b);
				$uid = $c["user_id"];
				$pid = $c["prod_id"];
				$qu = $c["quantity"];
				$amt = $c["amount"];

				$x = "SELECT * from products where product_id = '{$pid}'";
				$y = mysql_query($x);
				$z = mysql_fetch_assoc($y);
				$sto = $z["stocks"];
				$pri = $z["price"];

				$updated_stocks = $sto - $quantity;
				$updated_quantity = $qu + $quantity;
				$updated_amount = $amt + $amount;

				$insert = "UPDATE transaction set quantity = '{$updated_quantity}', amount = '{$updated_amount}' where user_id = '{$id}' and product_id = '{$product_id}'";
				$insert_result = mysql_query($insert);

				$update = "UPDATE products set stocks = '{$stocks_left}' Where product_id = '{$product_id}'";
				$update_result = mysql_query($update);

				if($update_result && $insert_result)
				{
					$_SESSION["success_message"] = $name . " has been added to your cart.";
					header("Location: cart.php");
				}
				else
				{
					$_SESSION["error_message"] = "Adding to cart failed.";
					
				}
			}
			else
			{
				$insert = "INSERT INTO transaction (product_id, user_id, quantity, amount, datecreated) values ('{$product_id}', '{$id}', '{$quantity}', '{$amount}', '{$date_created}')";
				$insert_result = mysql_query($insert);

				$update = "UPDATE products set stocks = '{$stocks_left}' Where product_id = '{$product_id}'";
				$update_result = mysql_query($update);

				if($update_result && $insert_result)
				{
					$_SESSION["success_message"] = $name . " has been added to your cart.";
					header("Location: cart.php");
				}
				else
				{
					$_SESSION["error_message"] = "Adding to cart failed.";
				}			
			}
		}
	}
?>

<?php 
	include '../includes/customerhead.php'; 
?>


                <div class="col-lg-12 col-xs-offset-2">
                    <div class="col-lg-8">
                        
                        	<div class="alert alert-success">
	                            <div class="panel-body alert alert-info">
	                                <div class="col-lg-12 col-xs-offset-2">
	                                    <form class="form-horizontal" role="form" method="post" action="add_to_cart.php?ProductId=<?php echo $product_id; ?>">
	                                    	<div class="col-sm-8">
	                                    		<?php echo error_message(); ?>
	                                    	</div><br><br><br><br>
	                                        <img src="<?php echo $row["product_picture"]; ?>" class="col-xs-offset-2" height="200px" width="200px"><br><br>
	                                        <div class="col-md-8">
	                                        <div class="thumbnail">
	                                        	<div class="caption">
	                                            <h3>Name: &nbsp;&nbsp;
	                                            	&nbsp;&nbsp;<?php echo $row["name"]; ?></h3>
	                                        	<br>

	                                            <h3>Stocks: &nbsp;
	                                            	&nbsp;&nbsp;<?php echo $row["stocks"]; ?></h3>
	                                        	<br>
	                                            <h3>Price: &nbsp;&nbsp;
	                                            	&nbsp;&nbsp;&#8369;<?php echo $row["price"]; ?></h3>
	                                        	<br>
	                                            <h3>Description: &nbsp;&nbsp;
	                                            	<?php echo $row["description"]; ?></h3>
	                                        	<br>
	                                        	<h3>Order Quantity:&nbsp;&nbsp;&nbsp; <input type="text" name="quantity" size="8" maxlength="3" onkeypress="numonly(event)" required></h3>
	                                        	<br>
			                                    <button class="btn btn-primary col-xs-offset-4" type="submit" name="submit" onclick="return confirm('Are you sure you want to add this to your cart?')">&nbsp;&nbsp;&nbsp;Add&nbsp;&nbsp;&nbsp;</button>
			                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			                                    <a href="main.php" class="btn btn-primary" role="button">&nbsp;&nbsp;Back&nbsp;&nbsp;</a>   
			                                </div>
			                                </div>
			                            </div>
		                                    <div class="col-lg-6">
		                                    </form> 
	                                </div>
	                            </div>
                            </div>
                       
                    </div>
                </div>
            </div>
  </body>
</html>