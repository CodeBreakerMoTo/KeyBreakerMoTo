<?php 
	require '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<?php
	$query = "SELECT A.transaction_id, A.product_id, A.user_id, A.quantity, A.amount, B.name, C.user_id from transaction A inner join products B on A.product_id = B.product_id inner join users C on A.user_id 
				= C.user_id where C.user_id = '{$id}'";
	$result = mysql_query($query);
?>
<?php
	$total = "SELECT SUM(amount) from transaction where user_id = '{$id}'";
	$total_result = mysql_query($total);
	$tres = mysql_fetch_assoc($total_result);
?>
<?php
	if(isset($_POST["submit"]))
	{
		$a = "SELECT * from transaction where user_id = '{$id}'";
		$b = mysql_query($a);

		$h = "SELECT * FROM transaction where user_id = '{$id}'";
		$j = mysql_query($h);
		while($k = mysql_fetch_assoc($j))
		{
			$p = $k["product_id"];

			$x = "SELECT * FROM products where product_id = '{$p}'";
			$y = mysql_query($x);
			$z = mysql_fetch_assoc($y);
			$sto = $z["stocks"];
			if($sto < 0)
			{
				$_SESSION["error_message"] = "Sorry we ran out of stock(s).";				
			}
			else
			{
				while($c = mysql_fetch_assoc($b))
				{
					$user_id = $c["user_id"];
					$product_id = $c["product_id"];
					$quant = $c["quantity"];
					$amount = $c["amount"];
					date_default_timezone_set('Asia/Manila');
			    	$date_created = date('Y-m-d G:i:s');

					$insert = "INSERT INTO checkout (product_id, user_id, quantity, amount, datecreated) VALUES ('{$product_id}', '{$user_id}', '{$quant}', '{$amount}', '{$date_created}')";
					$insert_result = mysql_query($insert);

					$del = "DELETE from transaction where user_id = '{$id}'";
					$del_result = mysql_query($del);

					if($insert_result && $del_result)
					{
						$_SESSION["success_message"] = "Checked Out.";
						header("Location: statement.php");
					}
					else
					{
						$_SESSION["error_message"] = "Checking out failed.";
					}
				}
			}
		}
	}
?>
<?php 
	include '../includes/customerhead2.php'; 
?>
	<br><br><br><br>
	<div class="col-lg-12">
		<div class="col-lg-12">
			<div class="col-lg-12">
				<div class="panel panel-inverse">
					<div class="panel panel-header" style="background-color: #222222;">
						<h2 style="color: white;">&nbsp;Shopping Cart</h2>
					</div>
					<div class="panel panel-body">
						<form action="cart.php" method="post">
						<?php echo error_message(); ?>
						<?php echo message(); ?>
						<?php echo success_message(); ?>
						<table class="table table-striped table-bordered">
							<thead>
								<tr>
									<th><center>Ordered Product(s)</center></th>
									<th><center>Quantity</center></th>
									<th><center>Amount</center></th>
									<th><center>Increase</center></th>
									<th><center>Decrease</center></th>
									<th><center>Remove</center></th>
								</tr>
							</thead>
							<tbody>
								<?php

								while($row = mysql_fetch_assoc($result))
								{
									$transaction_id = $row["transaction_id"];
									$prod_id = $row["product_id"];
									echo   "<tr>
											<td><center><br>" . $row["name"] . "</center></td>
											<td><center><br>" . $row["quantity"] . "</center></td>
											<td><center><br>" . $row["amount"] . "</center></td>
											<td><Center><a class=btn btn-primary href=increase.php?TransId=" . $transaction_id . "&ProdId=" . $prod_id . "><img src=../images/pos.png style='width: 50px; height:40px;'></img></center></a></td>
											<td><Center><a class=btn btn-primary href=decrease.php?TransId=" . $transaction_id . "&ProdId=" . $prod_id . "><img src=../images/neg.png style='width: 50px; height:40px;'></img></center></a></td>
											<td><Center><a class=btn btn-primary href=delete.php?TransId=" . $transaction_id . "&ProdId=" . $prod_id . " onclick=\"return confirm('Are you sure you want to remove this from your cart?')\">Remove</center></a></td>
											</tr>";
								}

								?>
							</tbody>
						</table>
						<h3><a href="clear_cart.php?UserID=<?php echo $id; ?>" class="btn btn-danger" role="button" onclick="return confirm('Are you sure you want to clear your cart?')"> Clear Cart</a>
						<button type="submit" name="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to check out?')"> Check Out</button></h3>
						<h3>Total Amount: &#8369;<?php echo $tres["SUM(amount)"]; ?></h3>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>