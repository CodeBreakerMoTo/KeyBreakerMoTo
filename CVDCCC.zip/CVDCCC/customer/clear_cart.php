<?php 
	include '../core/init.php'; 
?>

<?php
	$id = $_SESSION['user_id'];
?>

<?php
	$query = "SELECT * from transaction where user_id = '{$id}'";
	$result = mysql_query($query);
	$nums = mysql_num_rows($result);

	if(empty($nums))
	{
		$_SESSION["message"] = "Cart is empty.";
		header("Location: cart.php");
	}

	while($row = mysql_fetch_assoc($result))
	{
		$trans_id = $row["transaction_id"];
		$prod_id = $row["product_id"];
		$quantity = $row["quantity"];

		$get_prod = "SELECT * from products where product_id = '{$prod_id}'";
		$res_prod = mysql_query($get_prod);
		$rows = mysql_fetch_assoc($res_prod);
		$stocks = $rows["stocks"];

		$updated_stocks = $quantity + $stocks;

		$delete = "DELETE from transaction where transaction_id = '{$trans_id}'";
		$delete_result = mysql_query($delete);

		$update = "UPDATE products set stocks = '{$updated_stocks}' where product_id = '{$prod_id}'";
		$update_result = mysql_query($update);

		if($update_result && $delete_result)
		{
			$_SESSION["message"] = "Cart Cleared!";
			header("Location: cart.php");
		}
	}

?>