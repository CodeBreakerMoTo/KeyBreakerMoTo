<?php 
	include '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>

  </head>
  
  <body background="../images/bg2.jpg">
  
	<header>
		<div class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="home.php" class="navbar-brand">Grab-a-Shirt</a>
				</div>
				<div class="collpase navbar-collapse" id="navbar">
					<ul class="nav navbar-nav">
						<li><a href="profile.php">Profile</a></li>
						<li class=""><a href="home.php">Home</a></li>
						<li class=""><a href="main.php">Shirts</a></li>
						<li class=""><a href="about.php">About</a></li>
						<li class="active"><a href="contacts.php">Contact</a></li>
						<li><a href="cart.php">Cart</a></li>
					</ul>
					
					<form action="" class="navbar-form navbar-right">
						<a href="logout.php" class="btn btn-danger" role="button"> Log out</a>
					</form>
					
				</div>
			</div>
		</div>
		
	</header>
	
	<div class="col-md-2">
	
	</div>
	
	<div class="col-md-8">
	<div class="panel panel-default">
	<div class="panel-body">
	<td colspan="2"><b style="font-size:20px">Welcome to Grab-a-Shirt</b><br><br>
<table width="870" border="0" align="center" cellpadding="0" cellspacing="0" height="610">
<tbody>
<tr>
	<td background="../images/Clothes/Women/female16.png" style="background-repeat:no-repeat; background-position:right; padding-left: -10px;">	
	<table width="500" border="0" align="left" cellpadding="0" cellspacing="0">
    <tbody>
    <tr><td colspan="2" height="90"><font style="font:bold 20px/20px Arial, 'Helvetica', 'sans-serif'; display:block; padding:0 0 70px 0;">For More Information:</font></td></tr>
    <tr><td width="74"><img src="../images/Live.png" width="54" height="53" border="0" alt="Live" style="display:block; border:0; vertical-align:top;"></td>
    <td style="font:bold 20px/20px Arial, 'Helvetica', 'sans-serif';">LIVE CHAT</td></tr>
    <tr><td colspan="2" style="padding:10px 0 42px 0;"><font style="font:16px/20px Arial, 'Helvetica', 'sans-serif';">Available during our standard office hours,
	just visit our facebook page <strong style="color:#cd011f;">www.facebook.com/grab-a-shirt</strong></font></td></tr>

	<tr><td><img src="../images/Email.png" width="54" height="53" border="0" alt="Live" style="display:block; border:0; vertical-align:top;"></td>
    <td style="font:bold 20px/20px Arial, 'Helvetica', 'sans-serif';">EMAIL</td></tr>
    <tr><td colspan="2" style="padding:10px 0 42px 0;"><font style="font:16px/20px Arial, 'Helvetica', 'sans-serif';">You can access pre-sale and after-sale services. We're always happy to help, simply connect with us.</font></td></tr>

	<tr><td><img src="../images/Phone.png" width="54" height="53" border="0" alt="Live" style="display:block; border:0; vertical-align:top;"></td>
    <td style="font:bold 20px/20px Arial, 'Helvetica', 'sans-serif';">PHONE</td></tr>
    <tr>
      <td colspan="2" style="padding:10px 0 42px 0;"><p style="color:#cd011f;font-weight:bold;padding:5px 0;display:none;font-size:14px;" id="js_timeOffset">Phone closed at the moment (please submit a ticket, we will get back to you within one working day, thank you)</p><font style="font:16px/20px Arial, 'Helvetica', 'sans-serif';">High Quality international Customer Service Support Line in English, Please call us at 7:30-17:00(GMT+8) on our helpline number<span id="chat_ico">:</p>
    <strong style="color:#cd011f;" id="chat_phone">999-999-999 </strong></font></td></tr>
    </tbody>
    </table>
</td></tr>
</tbody>
</table>
	
	</div>
	</div>
	</div>
	<div class="col-md-2"></div>
    

  </body>
</html>