<?php 
	include '../core/init.php'; 
?>

<?php
	$id = $_SESSION['user_id'];
?>

<?php
	$trans_id = sanitize($_GET["TransId"]);
	$prod_id = sanitize($_GET["ProdId"]);

    if((!isset($_GET["TransId"]) || empty($trans_id)) || (!isset($_GET["ProdId"]) || empty($prod_id)))
    {
        header("Location: cart.php");
    }
?>

<?php
	
	$get = "SELECT * from products where product_id = '{$prod_id}'";
	$post = mysql_query($get);
	$se = mysql_fetch_assoc($post);

	$name = $se["name"];
	$price = $se["price"];
	$stocks = $se["stocks"];

	$get2 = "SELECT * from transaction where transaction_id = '{$trans_id}'";
	$post2 = mysql_query($get2);
	$se2 = mysql_fetch_assoc($post2);

	$quan = $se2["quantity"];

	if($quan == 1)
	{
		$updated_stocks = $stocks + 1;

		$up = "UPDATE products set stocks = '{$updated_stocks}' where product_id = '{$prod_id}'";
		$update = mysql_query($up);

		$query = "DELETE FROM transaction where transaction_id = '{$trans_id}'";
		$result = mysql_query($query);

		if($result && $update)
		{
			$_SESSION["message"] = $name . " has been removed from your cart.";
			header("Location: cart.php");
		}
	}
	else
	{
		$updated_stocks = $stocks + 1;
		$updated_quantity = $quan - 1;
		$updated_amount = $updated_quantity * $price;

		$query = "UPDATE transaction set quantity = '{$updated_quantity}', amount = '{$updated_amount}' where transaction_id = '{$trans_id}'";
		$result = mysql_query($query);

		$up = "UPDATE products set stocks = '{$updated_stocks}' where product_id = '{$prod_id}'";
		$update = mysql_query($up);

		if($result && $update)
		{
			header("Location: cart.php");
		}
		else
		{
			$_SESSION["message"] = "Decreasing failed.";
			header("Location: cart.php");
		}
	}
?>