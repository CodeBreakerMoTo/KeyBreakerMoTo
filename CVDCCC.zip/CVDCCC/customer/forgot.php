<?php
include '../core/init.php';

if(isset($_POST["send"]))
{	
	$hash = md5("123456");
	$email = $_POST["email"];
	$question = $_POST["question"];
	$answer = $_POST["answer"];

	$query = "SELECT * from users WHERE ";
	$query .= "email='{$email}'";

	$result = mysql_query($query);
	$row = mysql_num_rows($result);

	$user = mysql_fetch_assoc($result);
	$secret_question = $user["question"];
	$secret_answer = $user["answer"];
	$id = $user["user_id"];

	if($row === 0)
	{
		$errors[] = 'Email address does not exist!';
	}
	else if($question !== $secret_question)
	{
		$errors[] = 'Email address secret question does not match!';	
	}
	else if($answer !== $secret_answer)
	{
		$errors[] = 'Answer to question does not match!';
	}
	else if(($answer == $secret_answer) && ($question == $secret_question))
	{
		require 'class.phpmailer.php';

		$mail = new PHPMailer;
		$mail->From = $email;
		$mail->IsSMTP();                                      // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com';                 // Specify main and backup server
		$mail->Port = 587;                                    // Set the SMTP port
		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = 'louispaolo23@gmail.com';                // SMTP username
		$mail->Password = '09157883108';                  // SMTP password
		$mail->SMTPSecure = 'tls';                            // Enable encryption, 'ssl' also accepted

		$mail->From = 'jatestercoderes@gmail.com';
		$mail->FromName = 'CDVCCC';
		$mail->AddAddress($email, 'testing');  // Add a recipient
		$mail->AddAddress($email);               // Name is optional

		$mail->IsHTML(true);                                  // Set email format to HTML

		$mail->Subject = 'New Password';
		$mail->Body    = 'Your password has been updated to 123456.';
		$mail->AltBody = 'This is the body in plain text for non-HTML mail clients SSL';

		if(!$mail->Send()) 
		{
		   echo '<script type=text/javascript> alert(Message could not be sent. Mailer Error: ' . $mail->ErrorInfo . '); </script>';
		   exit;
		}

		$update = "UPDATE users SET ";
		$update .= "password = '{$hash}' ";
		$update .= "WHERE user_id = '{$id}' LIMIT 1";
		$res = mysql_query($update);

		$ok[] = 'Message sent.';
	}
}
?>
<script type="text/javascript">
function numonly(evt) 
	{
		var theEvent = evt || window.event;
		var key = theEvent.keyCode || theEvent.which;
		key = String.fromCharCode( key );
		var regex = /[0-9 \b]|\./;
		if( !regex.test(key) ) 
		{
			theEvent.returnValue = false;
			if(theEvent.preventDefault) theEvent.preventDefault();
		}
	}


function charonly(evt) 
{
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode( key );
	var regex = /[a-z A-Z\b]|\./;
	if( !regex.test(key) ) 
	{
		theEvent.returnValue = false;
		if(theEvent.preventDefault) theEvent.preventDefault();
	}
}
</script>
<head>
<!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>
</head>
<html>
	<body background="../images/bg2.jpg">
    <div class="container">
		<p></br></p>
		<div class="row"><br><br><br>
			<div class="col-md-4">
			</div>
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h3>Forgot Password?</h3>
							
						</div>
						<form action="forgot.php" method="post">
							<?php echo output_errors($errors); ?>
							<?php echo output($ok); ?>
							<div class="form-group">
    								<label for="txtbPassword">Email Address</label>
    							<div class="form-group">
    								<input type="email" class="form-control" id="email"maxlength="32" size="40" name="email" placeholder="Enter Email" required>
								</div>
  							</div>
  							<hr>
							<div class="form-group">
								<label class="control-label">Secret Question:</label> 
								<select class="form-control" name="question">
								  <option value="" disabled selected>Secret Question</option>
								  <option value="1">What is your favorite color?</option>
								  <option value="2">What is your pet's name?</option>
								  <option value="3">What is your mother's maiden name?</option>
								</select>
  							</div>

							<div class="form-group">
    								<label for="txtbPassword">Answer</label>
    							<div class="form-group">
    								<input type="text" onkeypress="charonly(event)" class="form-control" id="answer" maxlength="32" size="40" name="answer" >
								</div>
  							</div>
  							
							
							<p></br></p>
							
							<center><button type="reset" class="btn btn-info">Reset</button>
							<button type="submit" class="btn btn-info" name="send">Send to Mail</button></center><br>
							<a href="frmLogin.php">Back</a>
							
						</form>
					</div>
				</div>
		</div>
	</div>

  
  </body>
</html>