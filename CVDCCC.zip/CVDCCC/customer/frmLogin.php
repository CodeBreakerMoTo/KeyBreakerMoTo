<!DOCTYPE html>
<html lang="en">
  <?php include '../includes/head.php'; 
		include '../core/init.php'; 
	?>

  <?php include '../includes/lgnbody.php'; ?>
</html>