<?php 
	include '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Us</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>

   </head>
  
  <body background="../images/bg2.jpg">
  
	<header>
		<div class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="home.php" class="navbar-brand">Grab-a-Shirt</a>
				</div>
				<div class="collpase navbar-collapse" id="navbar">
					<ul class="nav navbar-nav">
						<li><a href="profile.php">Profile</a></li>
						<li class="active"><a href="home.php">Home</a></li>
						<li class=""><a href="main.php">Shirts</a></li>
						<li class=""><a href="about.php">About</a></li>
						<li><a href="contacts.php">Contact</a></li>
						<li><a href="cart.php">Cart</a></li>
					</ul>
					
					<form action="" class="navbar-form navbar-right">
						<a href="logout.php" class="btn btn-danger" role="button"> Log out</a>
					</form>
					
				</div>
			</div>
		</div>
		
	</header>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<br><br><br>
				<h1 style="font-size: 50px; color: white; text-shadow: 2px 1px black;" class="text-center">3 ways on how to order in GAS</h1>
				
			</div>
			<br><br><br><br><br><br><br><br><br>
			<div class="col-md-4">
				<img class="img-responsive center-block" src="../images/click.png">
				<h2 class="text-center" style="font-size: 40px ;color: white;text-shadow: 2px 1px black;">Choose Shirt</h2>
			</div>
			<div class="col-md-4">
				<img class="img-responsive center-block" src="../images/add.png">
				<h2 class="text-center"  style="font-size: 40px ; color: white;text-shadow: 2px 1px black;">Add to Cart</h2>
			</div>
			<div class="col-md-4">
				<img class="img-responsive center-block" src="../images/check.png">
				<h2 class="text-center" style="font-size: 40px ; color: white;text-shadow: 2px 1px black; ">Check Out</h2>
			</div>
		</div><br><br><br>

	<div class="col-md-12">
		<a type="button" href="main.php" class="center-block form-control btn btn-inverse" placeholder="Order now" style="height: 80px; width: 600px; color:#274257; font-size: 50px;">Order Now!</a>
		<br><br><br>
	</div>
	</div>