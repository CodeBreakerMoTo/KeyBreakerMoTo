<?php
	include '../core/init.php';
	
	if (empty($_POST) === false)
	{
		$username = $_POST	['txtbUser'];
		$password = $_POST ['txtbPassword'];
		
		if (empty($username) === true || empty($password) === true)
		{
			$errors[] = 'You need to enter a registered email and password.';
		}
		else if (user_exists($username) === false)
		{
			$errors[] = 'We can\'t find that email. Have you registered?';
		}
		else
		{
			$login = login($username, $password);
			if ($login === false)
			{
				$errors[] = 'The password you entered is incorrect!';
			}
			else
			{
				$_SESSION['user_id'] = $login;
				header('Location: home.php');
				exit();
			}
		}
		
	}
	include '../includes/head.php';
	
?>

	
	<body background="../images/bg.jpg">
    <div class="container">
		<p></br></p>
		<div class="row"><br><br><br>
			<div class="col-md-6">
				<img class="center-block" src="../images/gass.png" style="width: 400px;">
				<h3 class="text-center" style="color: white; text-shadow: 2px 0px black;">Your one stop online shop for t-shirt</h3>
			</div>
			<div class="col-md-1">
			</div>
			<div class="col-md-4"><br><br>	
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h3>Welcome to Grab a Shirt!</h3>
							<?php
								if (empty($errors) === false)
								{
									echo output_errors($errors);
								}
							?>
						</div>
						<form action="login.php" method="post">
							<div class="form-group">
    								<label for="txtbUser">Email Address</label>
    							<div class="form-group">
  									
  									<input type="email" class="form-control" id="txtbUser" name="txtbUser" maxlength="80" placeholder="Email Address">
								</div>
  							</div>
							<div class="form-group">
    								<label for="txtbPassword">Password</label>
    							<div class="form-group">
  									
  									<input type="password" class="form-control" id="txtbPassword"maxlength="32" name="txtbPassword" placeholder="Password">
								</div>
  							</div>
							<hr>
							<p></p>
							<button type="submit" class="btn btn-default"> Login</button>
							<button type="reset" class="btn btn-default"> Reset</button>
							
							
							<p></br></p>
							<a href="register.php">Don't have an acount yet? Sign up here!</a>
							<p></p>
							<a href="forgot.php">Forgot your password?</a>
						</form>
					</div>
				</div>
		</div>
	</div>

  
  </body>
	