<?php 
	require '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];
?>

<?php
	$query = "SELECT * FROM transaction where user_id = '{$id}'";
	$result = mysql_query($query);
	$num = mysql_num_rows($result);

	$rows = mysql_fetch_assoc($result);
	$quantity = $rows["quantity"];
	$product_id = $rows["product_id"];

	$get_prod = "SELECT * from products where product_id = '{$product_id}'";
	$get_result = mysql_query($get_prod);
	$prod_result = mysql_fetch_assoc($get_result);
	$stocks = $prod_result["stocks"];

	$updated_stocks = $quantity + $stocks;

	if($num > 0)
	{
		$del = "DELETE from transaction where user_id = '{$id}'";
		$del_result = mysql_query($del);

		$update = "UPDATE products set stocks = '{$updated_stocks}' where product_id = '{$product_id}'";
		$update_result = mysql_query($update);
	}

	unset($_SESSION["user_id"]);
	header("Location: frmLogin.php");
?>