  
  <?php 
		include '../core/init.php'; 
	?>
  <?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
  <?php 
		include '../includes/customerhead.php'; 
	?>
  
    <div class="container">
	<p></br></p>
		<div class="row">
			<div id="avail">
				
			
			</div>
		</div>
	</div>

  </body>
</html>