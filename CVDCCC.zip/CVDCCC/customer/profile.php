<?php 
	include '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<?php
	$query = "SELECT * from users where user_id = '{$id}'";
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);
?>

<?php 
	include '../includes/customerhead3.php'; 
?>
	
	<div class="col-md-2">
	
	</div>
	
	<div class="col-md-8">
	<div class="panel panel-default">
	<div class="panel-body">
	<br><br>
	<?php echo success_message(); ?>
	<?php echo error_message(); ?>
	<h3>Customer Profile</h3><br>
	<form action="update_profile.php" method="post">
	<div class="form-group">
		<label class="col-sm-3">First Name: </label><div class="col-sm-3"><input type="text" minlength="2" maxlength="10" onkeypress="charonly(event)" name="firstname" value = "<?php echo $row["first_name"]; ?>" class="form-control"></div>
	</div>
	<br><br><br>
	<div class="form-group">
		<label class="col-sm-3">Last Name: </label><div class="col-sm-3"><input type="text" minlength="2" maxlength="10" onkeypress="charonly(event)" name="lastname" value = "<?php echo $row["last_name"]; ?>" class="form-control"></div>
	</div>
	<br><br>
	<div class="form-group">
		<label class="col-sm-3">Email: </label><div class="col-sm-4"><input type="email" name="email" value = "<?php echo $row["email"]; ?>" class="form-control"></div>
	</div>
	<br><br>
	<div class="form-group">
		<label class="col-sm-3">Address: </label><div class="col-sm-4"><textarea name="address" onkeypress="letternumber(event)" class="form-control"><?php echo $row["address"]; ?></textarea></div>
	</div>
	<br><br><br>
	<div class="form-group">
		<label class="col-sm-3">Mobile Number: </label><div class="col-sm-3"><input type="text" minlength="11" maxlength="11" onkeypress="numonly(event)" value = "<?php echo $row["contact_number"]; ?>" name="number" class="form-control"></div>
	</div>
	<br><br>
	<div class="form-group">
		<label class="col-sm-3">Password: </label><div class="col-sm-3"><input type="password" minlength="6" maxlength="15" name="password1" placeholder="New Password" class="form-control"></div>
	</div>
	<br><br>
	<div class="form-group">
		<label class="col-sm-3">Confirm Password: </label><div class="col-sm-3"><input type="password" minlength="6" maxlength="15" name="password2" placeholder="Re-enter New Password" class="form-control"></div>
	</div><br><br>
	<div class="col-xs-offset-3"><button type="submit" name="submit" class="btn btn-primary col-sm-4">Update</button></div>
	</form>
	</div>
	</div>
	</div>
	<div class="col-md-2"></div>
    

  </body>
</html>