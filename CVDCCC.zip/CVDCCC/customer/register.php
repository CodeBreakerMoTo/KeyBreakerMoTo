<!DOCTYPE html>
<script type="text/javascript">
function numonly(evt) 
	{
		var theEvent = evt || window.event;
		var key = theEvent.keyCode || theEvent.which;
		key = String.fromCharCode( key );
		var regex = /[0-9 \b]|\./;
		if( !regex.test(key) ) 
		{
			theEvent.returnValue = false;
			if(theEvent.preventDefault) theEvent.preventDefault();
		}
	}

function letternumber(evt) 
{ 
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode( key );
	var regex = /[a-z A-Z0-9_\b]|\ /;
	if( !regex.test(key) ) 
	{
		theEvent.returnValue = false;
		if(theEvent.preventDefault) theEvent.preventDefault();
	}
}

function charonly(evt) 
{
	var theEvent = evt || window.event;
	var key = theEvent.keyCode || theEvent.which;
	key = String.fromCharCode( key );
	var regex = /[a-z A-Z\b]|\./;
	if( !regex.test(key) ) 
	{
		theEvent.returnValue = false;
		if(theEvent.preventDefault) theEvent.preventDefault();
	}
}
</script>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Customer Registration</title>

     <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>
	
	<script src="../javascript/validation.php"></script>
  </head>
  
  <?php 
	include '../core/init.php';
	
	if (empty($_POST)=== false)
	{
		$required_fields = array('txtbFirstName', 'txtbLastName', 'txtbEmail', 'txtbAddress', 'txtbPassword', 'txtbPasswordAgain', 'txtbPNumber');
		foreach ($_POST as $key => $value)
		{
			if (empty($value) && in_array($key, $required_fields) === true)
			{
				$errors[] = 'Fields with an asterisk are required!';
				break 1;
			}
		}
		
		if (empty($errors) === true)
		{
			if (user_exists($_POST['txtbEmail']) === true)
			{
				$errors[] = 'Sorry the email \'' . $_POST['txtbEmail'] . '\' is already taken.';
			}
			
			if (strlen($_POST['txtbPassword']) < 6)
			{
				$errors[] = 'Your password must be at least 6 characters!';
			}
			
			if ($_POST['txtbPassword'] !== $_POST['txtbPasswordAgain'])
			{
				$errors[] = 'The password you enter does not match!';
			}
			
			if (strlen($_POST['txtbPNumber']) < 11)
			{
				$errors[] = 'The phone number you have entered is incorrect!';
			}

		}
	}
	
  ?>
  
  <body background="../images/bg2.jpg">
    <div class="container">
		<p></br></p>
		<div class="row">
			<div class="col-md-2">
			</div>
			<div class="col-md-8">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h2>Sign Up</h2>
							
							<?php
							$firstname = "";
							$lastname =  "";
							$gender = "";
							$email = "";
							$address = "";
							$number = "";
							$bday = "";
							$question = "";
							$answer = "";

							if(isset($_POST["submit"]))
							{
								$firstname = $_POST['txtbFirstName'];
							$lastname =  $_POST['txtbLastName'];
							$gender = $_POST['rbGender'];
							$email = $_POST['txtbEmail'];
							$address = $_POST['txtbAddress'];
							$number = $_POST['txtbPNumber'];
							$bday = $_POST['dtpDateOfBirth'];
							$question = $_POST['question'];
							$answer = $_POST['answer'];
							
								if (empty($_POST) === false && empty($errors) === true)
								{
									$register_data = array(
										'first_name'		=> $_POST['txtbFirstName'],
										'last_name' 		=> $_POST['txtbLastName'],
										'gender' 			=> $_POST['rbGender'],
										'email' 			=> $_POST['txtbEmail'],
										'address' 			=> $_POST['txtbAddress'],
										'password'			=> $_POST['txtbPassword'],
										'contact_number' 	=> $_POST['txtbPNumber'],
										'birthdate' 		=> $_POST['dtpDateOfBirth'],
										'question' 			=> $_POST['question'],
										'answer' 			=> $_POST['answer'] 
									);
									
									register_user($register_data);
									
									header('Location: frmLogin.php');
									exit();
									
								}
								else if (empty($errors)=== false)
								{
									echo output_errors($errors);
							        $_SESSION["Form_Email"] =$email ;
							        $_SESSION["Form_Firstname"] =$firstname ;
							        $_SESSION["Form_Lastname"] =$lastname;
							        $_SESSION["Form_Mobile"] =$number ;
							        $_SESSION["Form_Address"] =$address;
							        $_SESSION["Form_Birthmonth"] =$answer ;
							        $_SESSION["Form_Birthday"]=$question;
							        $_SESSION["Form_Birthyear"]=$bday;
								}
							}
							?>
							
						</div>
						<?php if(empty($errors)){ ?>
							<form class="form-inline" action="" method="post">
																<!-- FIRST NAME -->
								<label for="txtbFirstName">Name:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" class="form-control" onkeypress="charonly(event)" required="required" id="txtbFirstName" name="txtbFirstName" size="30" maxlength="64" placeholder="First Name" onkeypress="return isLetter(event)">
								</div>
																<!-- LAST NAME -->
								<div class="form-group">
									<font color="red">* </font><input type="text" class="form-control" onkeypress="charonly(event)" required="required" id="txtbLastName" name="txtbLastName" size="30" maxlength="64" placeholder="Last Name" onkeypress="return isLetter(event)">
								</div>
								<p></p>
																<!-- Gender -->
								<div class="form-group">
									<label for="rbGender">Gender:</label>
										<label class="radio-inline">
											<input type="radio" name="rbGender" id="rb1" value="Male"> Male
										</label>
										<label class="radio-inline">
											<input type="radio" name="rbGender" id="rb2" value="Female"> Female
										</label>
								</div>
								<p></p>
																<!-- EMAIL -->
								<label for="txtbEmail">Email:</label>
								<div class="form-group">
									<font color="red">* </font><input type="email" class="form-control" required="required" id="txtbEmail" name="txtbEmail" size="71" maxlength="80" placeholder="E-mail Address">
								</div>
								<p></p>	
																<!-- ADDRESS -->
								<label for="txtbAddress">Address:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" onkeypress="letternumber(event)" class="form-control" required="required" id="txtbAddress" name="txtbAddress" size="68" maxlength="100" placeholder="Address">
								</div>
								<p></p>	
																<!-- PASSWORD -->
								<label for="txtbPassword">Password:</label>
								<div class="form-group">
									<font color="red">* </font><input type="password" class="form-control" required="required" id="txtbPassword" name="txtbPassword" size="30" maxlength="14" placeholder="Password">
								
								</div>
																<!-- PASSWORD AGAIN -->
																<p></p>
								<label for="txtbPasswordAgain">Re-enter Password:</label>
								<div class="form-group">
									<font color="red">* </font><input type="password" class="form-control" required="required" id="txtbPasswordAgain" name="txtbPasswordAgain" size="30" maxlength="14" onChange="checkPasswordMatch()" placeholder="Re-enter your password">
								</div>
								<p></p>	
																<!-- CONTACT NUMBER -->
								<label for="txtbPNumber">Contact Number:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" class="form-control" onkeypress="numonly(event)" required="required" required="required" id="txtbPNumber" name="txtbPNumber" size="33" maxlength="11" placeholder="Contact Number" onkeypress="return isNumber(event)">
								</div>
								<p></p>	
																<!-- BIRTHDAY -->
								<div class="form-group">
									<label class="control-label">Birthdate:</label> 
									
									<input type = "date" class="form-control" name = "dtpDateOfBirth" required="required" min = "1900-01-01" max = "2016-02-18">
								</div><p></p>

								<div class="form-group">
									<label class="control-label">Secret Question:</label> 
									<select required="required" class="form-control" name="question">
									  <option value="" disabled selected>Secret Question</option>
									  <option value="1">What is your favorite color?</option>
									  <option value="2">What is your pet's name?</option>
									  <option value="3">What is your mother's maiden name?</option>
									</select>
								  <label class="control-label">Answer:</label>
								  <font color="red">* </font><input type="text" class="form-control" onkeypress="charonly(event)" required="required" id="answer" name="answer" size="15" maxlength="11" placeholder="Answer" onkeypress="return isLetter(event)">
								
								</div>
								
								<hr>
								<div class="col-xs-offset-4">
									
									<button type="submit" name="submit" class="btn btn-success">Create Account</button>
								</div>
								<p></p>
								<a class="btn btn-default" href="frmLogin.php">Back</a>
							</form>
							  <?php
							  }else{
							    $field = sticky_form_user();
							    ?>
							<form class="form-inline" action="" method="post">
																<!-- FIRST NAME -->
								<label for="txtbFirstName">Name:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" value="<?php echo $field["FirstName"]; ?>" class="form-control" onkeypress="charonly(event)" required="required" id="txtbFirstName" name="txtbFirstName" size="30" maxlength="64" placeholder="First Name" onkeypress="return isLetter(event)">
								</div>
																<!-- LAST NAME -->
								<div class="form-group">
									<font color="red">* </font><input type="text" value="<?php echo $field["LastName"]; ?>" class="form-control" onkeypress="charonly(event)" required="required" id="txtbLastName" name="txtbLastName" size="30" maxlength="64" placeholder="Last Name" onkeypress="return isLetter(event)">
								</div>
								<p></p>
																<!-- Gender -->
								<div class="form-group">
									<label for="rbGender">Gender:</label>
										<label class="radio-inline">
											<input type="radio" name="rbGender" id="rb1" value="Male" required="required"> Male
										</label>
										<label class="radio-inline">
											<input type="radio" name="rbGender" id="rb2" value="Female" required="required"> Female
										</label>
								</div>
								<p></p>
																<!-- EMAIL -->
								<label for="txtbEmail">Email:</label>
								<div class="form-group">
									<font color="red">* </font><input type="email" value="<?php echo $field["Email"]; ?>" class="form-control" required="required" id="txtbEmail" name="txtbEmail" size="71" maxlength="80" placeholder="E-mail Address">
								</div>
								<p></p>	
																<!-- ADDRESS -->
								<label for="txtbAddress">Address:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" value="<?php echo $field["Address"]; ?>" onkeypress="letternumber(event)" class="form-control" required="required" id="txtbAddress" name="txtbAddress" size="68" maxlength="100" placeholder="Address">
								</div>
								<p></p>	
																<!-- PASSWORD -->
								<label for="txtbPassword">Password:</label>
								<div class="form-group">
									<font color="red">* </font><input type="password" class="form-control" required="required" id="txtbPassword" name="txtbPassword" size="30" maxlength="14" placeholder="Password">
								
								</div>
																<!-- PASSWORD AGAIN -->
																<p></p>
								<label for="txtbPasswordAgain">Re-enter Password:</label>
								<div class="form-group">
									<font color="red">* </font><input type="password" class="form-control" required="required" id="txtbPasswordAgain" name="txtbPasswordAgain" size="30" maxlength="14" placeholder="Re-enter your password"><span id="check"></span>
								</div>
								<p></p>	
																<!-- CONTACT NUMBER -->
								<label for="txtbPNumber">Contact Number:</label>
								<div class="form-group">
									<font color="red">* </font><input type="text" class="form-control" value="<?php echo $field["Mobile"]; ?>" onkeypress="numonly(event)" required="required" required="required" id="txtbPNumber" name="txtbPNumber" size="33" maxlength="11" placeholder="Contact Number" onkeypress="return isNumber(event)">
								</div>
								<p></p>	
																<!-- BIRTHDAY -->
								<div class="form-group">
									<label class="control-label">Birthdate:</label> 
									
									<input type = "date" class="form-control" name = "dtpDateOfBirth" required="required" min = "1900-01-01" max = "2016-02-18">
								</div><p></p>

								<div class="form-group">
									<label class="control-label">Secret Question:</label> 
									<select required="required" class="form-control" name="question">
									  <option value="" disabled selected>Secret Question</option>
									  <option value="1">What is your favorite color?</option>
									  <option value="2">What is your pet's name?</option>
									  <option value="3">What is your mother's maiden name?</option>
									</select>
								  <label class="control-label">Answer:</label>
								  <font color="red">* </font><input type="text" class="form-control" onkeypress="charonly(event)" required="required" id="answer" name="answer" size="15" maxlength="11" placeholder="Answer" onkeypress="return isLetter(event)">
								
								</div>
								
								<hr>
								<div class="col-xs-offset-4">
									
									<button type="submit" name="submit" class="btn btn-success">Create Account</button>
								</div>
								<p></p>
								<a class="btn btn-default" href="frmLogin.php">Back</a>
							</form>
							<?php
						}
						?>
					</div>
				</div>
		</div>
	</div>
	<div class="col-md-2"></div>
  <script src = "jquery.js"></script>
	<script>
		
		$("#check").validate({
			rules: {
				password: "required",
				password_again: {
					equalTo: "#txtbPassword"
				}
			}
		})
	</script>
	
  </body>
</html>
<?php
session_unset();
?>