<?php 
	require '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<?php
	$query = "SELECT A.check_id, A.datecreated, A.product_id, A.user_id, A.quantity, A.amount, B.name, B.price, C.user_id from checkout A inner join products B on A.product_id = B.product_id inner join users C on A.user_id 
				= C.user_id where C.user_id = '{$id}'";
	$result = mysql_query($query);

	 date_default_timezone_set('Asia/Manila');
    $date_today = date('Y-m-d');
?>
<?php
	$total = "SELECT SUM(amount) from checkout where user_id = '{$id}'";
	$total_result = mysql_query($total);
	$tres = mysql_fetch_assoc($total_result);

	$info = "SELECT * FROM users where user_id = '{$id}'";
	$info_res = mysql_query($info);
	$ii = mysql_fetch_assoc($info_res);
?>
<?php 
	include '../includes/customerhead2.php'; 
?>
	<br><br><br><br>
	<div class="col-lg-12">
		<div class="col-lg-12">
			<div class="col-lg-12">
				<div class="panel panel-inverse">
					<div class="panel panel-header" style="background-color: #222222;">
						<h2 style="color: white;">&nbsp;Billing Statement</h2>
					</div>
					<div class="panel panel-body">
						<div class="col-md-4">
							<h3>Customer Information:</h3>
							Name: <b><?php echo $ii["first_name"]; ?> <?php echo $ii["last_name"]; ?> </b><br><br>
							Email: <b><?php echo $ii["email"]; ?></b><br><br>
							Address: <b><?php echo $ii["address"]; ?></b><br><br>
							Contact Number: <b><?php echo $ii["contact_number"]; ?></b><br><br><br>
							<button onclick="myFunction()" class="col-sm-3 btn btn-primary">Print</button>
						</div>
						<div class="col-md-4">

						<h3>Shirts Ordered:</h3>
						<ul>
							<?php
								while($row = mysql_fetch_assoc($result))
								{
									$date_of_load = $row["datecreated"];
									$date_transaction = strtotime($date_of_load);
                                    $compare_date= date("Y-m-d",$date_transaction);
                                    if($date_today === $compare_date)
                                    {
										echo "<li>" . $row["name"] . " ---------> " . $row["quantity"] . " ---------> &#8369;" . $row["price"] . "</li><br>";
									}
								}
							?>
						</ul>
						<h3>Total Amount: &#8369;<?php echo $tres["SUM(amount)"]; ?></h3>
						
					</div>
					<div class="col-md-4">
						<img class="center-block" src="../images/gass.png" style="background-color: #222222; width: 370px; height:250px;">
					</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<script>
function myFunction()
{
	window.print();
}
</script>
</body>
</html>