  <?php 
		include '../core/init.php'; 
	?>
	<?php
$query = "SELECT * from products where stocks > 0";
$result = mysql_query($query);
?>
<?php
					while($row=mysql_fetch_assoc($result))
					{
						$product_id = $row["product_id"];
						echo "<div class='col-md-4'><div class='thumbnail'>
						   		<img src='" . $row["product_picture"] . "' width='200px' height='300px'>
									<div class='caption'>
										<h3>" . $row["name"] . "</h3>
										<h4>&#8369;" . $row["price"] . "</h4>
										<h4>Stocks: " . $row["stocks"] . "</h4>
										<h4>Description: " . $row["description"] . "</h4>
											<a href='add_to_cart.php?ProductId=" . $product_id . "' class='btn btn-primary'> Add to Cart</a>
												
									</div>
								</div>
						</div>";
					}
					?>