<?php 
	include '../core/init.php'; 
?>
<?php
	$id = $_SESSION['user_id'];

	if(!$id)
	{
		header("Location: frmLogin.php");
	}
?>
<?php
	if(isset($_POST["submit"]))
	{
		$fname = sanitize($_POST["firstname"]);
		$lname = sanitize($_POST["lastname"]);
		$email = sanitize($_POST["email"]);
		$address = sanitize($_POST["address"]);
		$number = sanitize($_POST["number"]);
		$password1 = sanitize($_POST["password1"]);
		$password2 = sanitize($_POST["password2"]);
		$str1 = strlen($password1);
		$str2 = strlen($password2);

		if(($str1 > 0) && ($str2 > 0))
		{
			if($password1 !== $password2)
			{
				$_SESSION["error_message"] = "Password do not match!";
				header("Location: profile.php");
			}
			else if($password1 === $password2)
			{
				$pass = md5($password1);

				$update = "UPDATE users set first_name = '{$fname}', last_name = '{$lname}', email = '{$email}', address = '{$address}', contact_number = '{$number}', password = '{$pass}' where user_id = '{$id}'";
				$res = mysql_query($update);
				if($res)
				{
					$_SESSION["success_message"] = "Profile Updated.";
					header("Location: profile.php");
				}
				else
				{
					$_SESSION["error_message"] = "Update Failed.";
					header("Location: profile.php");
				}
			}
		}
		else
		{
			$update2 = "UPDATE users set first_name = '{$fname}', last_name = '{$lname}', email = '{$email}', address = '{$address}', contact_number = '{$number}' where user_id = '{$id}'";
			$res2 = mysql_query($update2);
			if($res2)
			{
				$_SESSION["success_message"] = "Profile Updated.";
				header("Location: profile.php");
			}
			else
				{
					$_SESSION["error_message"] = "Update Failed.";
					header("Location: profile.php");
				}
		}
	}
?>