-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 15, 2016 at 04:36 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cvdccc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`admin_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `first_name`, `last_name`, `username`, `password`) VALUES
(1, 'Cyrus Vanj', 'Dela Cruz', 'vyrus25', '25d55ad283aa400af464c76d713c07ad');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE IF NOT EXISTS `checkout` (
`check_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `datecreated` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `checkout`
--

INSERT INTO `checkout` (`check_id`, `product_id`, `user_id`, `quantity`, `amount`, `datecreated`) VALUES
(1, 13, 14, 3, 1200, '2016-03-13 13:57:10'),
(2, 16, 14, 1, 400, '2016-03-13 13:58:52'),
(3, 14, 17, 2, 800, '2016-03-13 14:14:47'),
(4, 16, 17, 3, 1200, '2016-03-13 14:14:47'),
(5, 16, 17, 8, 3200, '2016-03-13 14:33:34'),
(6, 14, 17, 3, 1200, '2016-03-13 14:33:34'),
(7, 17, 14, 2, 1000, '2016-03-15 00:26:31'),
(9, 14, 15, 5, 2000, '2016-03-15 15:42:22'),
(10, 16, 15, 4, 1600, '2016-03-15 15:42:22'),
(11, 13, 15, 2, 800, '2016-03-15 15:51:36'),
(12, 14, 15, 2, 800, '2016-03-15 16:07:46'),
(13, 14, 15, 1, 400, '2016-03-15 16:11:41'),
(14, 17, 15, 1, 500, '2016-03-15 16:11:41'),
(15, 16, 14, 1, 400, '2016-08-15 10:33:57');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
`product_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `product_picture` varchar(500) NOT NULL,
  `stocks` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `product_picture`, `stocks`, `price`, `description`) VALUES
(14, 'Im an Engineer T Shirt', 'iscollege.png', 12, 400, 'Cotton'),
(16, 'Engineering Orange', 'eng.png', 9, 400, 'Cotton'),
(17, 'T Shirt', 'tsm.png', 17, 500, 'cotton'),
(18, 'Engineering Blue', 'engnr.png', 100, 300, 'Cotton'),
(19, 'Batang 90s T Shirt', '90s.png', 40, 300, 'Small Medium Large');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
`transaction_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `datecreated` datetime DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`user_id` int(11) NOT NULL,
  `first_name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `last_name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `gender` varchar(6) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(80) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `contact_number` varchar(11) COLLATE latin1_general_ci NOT NULL,
  `birthdate` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `question` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `answer` varchar(255) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `gender`, `email`, `address`, `password`, `contact_number`, `birthdate`, `question`, `answer`) VALUES
(14, 'Cyrus Vanj', 'Dela Cruz', 'Male', 'cvdc_vyrus25@yahoo.com', '298 C. Arellano St. Malabon City', '25d55ad283aa400af464c76d713c07ad', '09435667712', '1997-02-13', '1', 'blue'),
(15, 'ervin', 'soligam', 'Male', 'ervinsoligam@gmail.com', 'valenzuela city', '25d55ad283aa400af464c76d713c07ad', '09352342725', '1974-07-08', '1', 'pink');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
 ADD PRIMARY KEY (`check_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
 ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
 ADD PRIMARY KEY (`transaction_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
MODIFY `check_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
