<html>

	<script language=javascript>	
	var numOfOrder = document.getElementById("txtbNumOrder").value;
	var inStock = document.getElementById("txtbInStock").value;
	
	function computeBill()
	{
		var numOfOrder = document.getElementById("txtbNumOrder").value;
		var inStock = document.getElementById("txtbInStock").value;
		
		if ((numOfOrder <= inStock) && (numOfOrder > 0))
			{
				document.getElementById("txtbInStock").value = inStock - numOfOrder;
				document.getElementById("txtbTotal").value = 600 * numOfOrder;
				
				alert("Your order has been processed! Thank you for shopping with us.");
				
			}
		else if ((numOfOrder == "") || (numOfOrder == "0"))
			{
				alert("Please enter the amount you wish to order.");
				
			}
		else
		{
			alert("Your number of order exceeds the available stocks of the store.");
		}	
	}
	
	function test()
	{
		
		
	}
	
	</script>

<body>


<form name="frmMain" class="form-inline" action="" method="">
	<div class="form-group">
		<h4>In Stock: </h4><input type="text" class="form-control" id=txtbInStock size="15" value="30" READONLY>
	</div>
	<p></p>
	<div class="form-group">
		<h4>Price: </h4>&#8369;<input type="text" class="form-control" id=txtbPrice size="15" value="600" READONLY>
	</div>
	<hr>
	<div class="form-group">
		<h4>Number of order(s): </h4><input type="text" class="form-control" id=txtbNumOrder value="0" size="15" value="">
	</div>
	<p></p>
	<div class="form-group">
		<h4>Total Bill: </h4>&#8369;<input type="text" class="form-control" id=txtbTotal size="15" value="0" READONLY>
	</div>
</form>

<p></p>
<button type="submit" class="btn btn-success" onClick="computeBill()"><span class="glyphicon glyphicon-check"></span> Order!</button>


</body>
</html>