<?php
    $id = $_SESSION['admin_id'];

    if(!$id)
    {
        header("Location: login_admin.php");
    }
?>
<script type="text/javascript">
function numonly(evt) 
    {
        var theEvent = evt || window.event;
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode( key );
        var regex = /[0-9 \b]|\ /;
        if( !regex.test(key) ) 
        {
            theEvent.returnValue = false;
            if(theEvent.preventDefault) theEvent.preventDefault();
        }
    }

function letternumber(evt) 
{ 
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    var regex = /[a-z A-Z0-9_\b]|\ /;
    if( !regex.test(key) ) 
    {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
}

function charonly(evt) 
{
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    var regex = /[a-z A-Z\b]|\./;
    if( !regex.test(key) ) 
    {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
}
</script>	
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

        <link href="../bower_components/bootstrap-switch-master/docs/css/bootstrap.min.css" rel="stylesheet">
    <link href="../bower_components/bootstrap-switch-master/docs/css/highlight.css" rel="stylesheet">
    <link href="../bower_components/bootstrap-switch-master/dist/css/bootstrap2/bootstrap-switch.css" rel="stylesheet">
    <link href="http://getbootstrap.com/assets/css/docs.min.css" rel="stylesheet">
    <link href="../bower_components/bootstrap-switch-master/docs/css/main.css" rel="stylesheet">

<link href="css/bootstrap.min.css" rel="stylesheet">

     <script src="js/bootstrap.min.js"></script>
    <title>Grab-a-Shirt</title>

    <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="../bower_components/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  </head>

  <!-- jQuery -->
    <script src="../bower_components/jquery/dist/jquery.min.js"></script>


    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
  
<body background="../images/bg2.jpg">

<header>
		
		<div class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="" class="navbar-brand">Grab-a-Shirt</a>
				</div>
				<div class="collpase navbar-collapse" id="navbar">
					<ul class="nav navbar-nav">
						<li><a href="usersview.php">View Clients</a></li>
						<li class="active"><a href="manage.php">Manage Products</a></li>
						<li><a href="salesrep.php">Sales Report</a></li>
					</ul>
					
					<form action="" class="navbar-form navbar-right">
						<a href="logout.php" class="btn btn-danger" role="button"> Log out</a>
					</form>
					
				</div>
			</div>
		</div>
		
	</header>