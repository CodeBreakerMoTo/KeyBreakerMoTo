
<script type="text/javascript">
function numonly(evt) 
    {
        var theEvent = evt || window.event;
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode( key );
        var regex = /[0-9 \b]|\ /;
        if( !regex.test(key) ) 
        {
            theEvent.returnValue = false;
            if(theEvent.preventDefault) theEvent.preventDefault();
        }
    }

function letternumber(evt) 
{ 
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    var regex = /[a-z A-Z0-9_\b]|\ /;
    if( !regex.test(key) ) 
    {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
}

function charonly(evt) 
{
    var theEvent = evt || window.event;
    var key = theEvent.keyCode || theEvent.which;
    key = String.fromCharCode( key );
    var regex = /[a-z A-Z\b]|\./;
    if( !regex.test(key) ) 
    {
        theEvent.returnValue = false;
        if(theEvent.preventDefault) theEvent.preventDefault();
    }
}
</script>
<!DOCTYPE html>
<html lang="en">
  
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Grab-a-Shirt</title>

    <!-- Bootstrap -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

	 <script src="../js/bootstrap.min.js"></script>

  </head>
  
  <body background="../images/bg2.jpg">
  
	<header>
		<div class="navbar navbar-default navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="home.php" class="navbar-brand">Grab-a-Shirt</a>
				</div>
				<div class="collpase navbar-collapse" id="navbar">
					<ul class="nav navbar-nav">
						<li class="active"><a href="profile.php">Profile</a></li>
						<li class=""><a href="home.php">Home</a></li>
						<li class=""><a href="main.php">Shirts</a></li>
						<li class=""><a href="about.php">About</a></li>
						<li><a href="contacts.php">Contact</a></li>
						<li><a href="cart.php">Cart</a></li>
					</ul>
					
					<form action="" class="navbar-form navbar-right">
						<a href="logout.php" class="btn btn-danger" role="button"> Log out</a>
					</form>
					
				</div>
			</div>
		</div>
		
	</header>